-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2022 at 05:20 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `6th_sem_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ID` int(11) NOT NULL,
  `UNIQUE_ID` varchar(500) NOT NULL DEFAULT '-',
  `F_NAME` varchar(500) NOT NULL,
  `L_NAME` varchar(500) NOT NULL,
  `EMAIL` varchar(500) NOT NULL,
  `PASSWORD` varchar(500) NOT NULL,
  `GENDER` varchar(500) NOT NULL,
  `DOB` varchar(500) NOT NULL,
  `CONTACT` varchar(500) NOT NULL,
  `AADHAR` varchar(500) NOT NULL,
  `CITY` varchar(500) NOT NULL,
  `IMAGE_PATH` varchar(500) NOT NULL,
  `STATUS` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ID`, `UNIQUE_ID`, `F_NAME`, `L_NAME`, `EMAIL`, `PASSWORD`, `GENDER`, `DOB`, `CONTACT`, `AADHAR`, `CITY`, `IMAGE_PATH`, `STATUS`) VALUES
(1, '1', 'Yash', 'Kheni', 'yashkheni5849@gmail.com', 'yash', 'male', '20/02/2001', '9408150059', '8008 3137 8677', 'Surat', 'admin/yashkheni5849@gmail.com/1.90897827.d10.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `ID` int(11) NOT NULL,
  `F_NAME` varchar(500) NOT NULL,
  `L_NAME` varchar(500) NOT NULL,
  `HOSPITAL` varchar(500) NOT NULL,
  `U_NAME` varchar(500) NOT NULL,
  `EMAIL` varchar(500) NOT NULL,
  `PASSWORD` varchar(500) NOT NULL,
  `DOB` varchar(500) NOT NULL,
  `GENDER` varchar(500) NOT NULL,
  `ADDRESS` varchar(500) NOT NULL,
  `STATE` varchar(500) NOT NULL,
  `CITY` varchar(500) NOT NULL,
  `PIN` varchar(500) NOT NULL,
  `CONTACT` varchar(500) NOT NULL,
  `SPECIALIST` varchar(500) NOT NULL,
  `BIO` varchar(500) NOT NULL,
  `IMAGE_PATH` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`ID`, `F_NAME`, `L_NAME`, `HOSPITAL`, `U_NAME`, `EMAIL`, `PASSWORD`, `DOB`, `GENDER`, `ADDRESS`, `STATE`, `CITY`, `PIN`, `CONTACT`, `SPECIALIST`, `BIO`, `IMAGE_PATH`) VALUES
(1, 'Heet', 'Patel', 'BAPS PRAMUKH SWAMI HOSPITAL', 'heetpatel', 'hiitpatel@gmail.com', 'yash', '14/09/2001', 'male', '2/A , Vaishnav Society, Dhandhuka', 'Guajrat', 'Dhandhuka', '382460', '8490883283', 'Skin Specialist', 'Exe 5 yrs in skin consultancy.', 'doctor/heetpatel/1..11.png'),
(2, 'Yash', 'Kheni', 'BAPS PRAMUKH SWAMI HOSPITAL', 'yashkheni', 'yashkheni5849@gmail.com', 'yash', '31/01/2001', 'male', 'PUNAGAM', 'Gujarat', 'Surat', '395010', '08000892690', 'Heart Specialist', 'Exp 10 yrs', 'doctor/yashkheni/1..d1.png'),
(3, 'Dhyey', 'Bhimani', 'BAPS PRAMUKH SWAMI HOSPITAL', 'dhyeybhimani', 'dhyey@gmail.com', 'yash', '06/03/2002', 'male', 'jimu Society', 'Gujarat', 'Vapi', '23456', '948463545376', 'Dental ', 'Exe 6 yrs', 'doctor/dhyeybhimani/1..d10.jpg'),
(4, 'Priyal', 'Parikh', 'BAPS PRAMUKH SWAMI HOSPITAL', 'priyalparikh', 'Priyal@gmail.com', 'yash', '06/02/2001', 'female', '3 /A opp osia g mart', 'Gujarat', 'Gandhinagar', '866445', '9363564534', 'Gynaecologist', 'Exe 5 yrs', 'doctor/priyalparikh/1..13.png'),
(5, 'Meet', 'Guna', 'BAPS PRAMUKH SWAMI HOSPITAL', 'meetguna', 'meet15@gmail.com', 'yash', '07/03/2002', 'male', '2/A , raj garden', 'Gujarat', 'Surat', '263633', '9345545325', 'MD Phycision', 'Ex 3 yrs', 'doctor/meetguna/1..d6.png'),
(6, 'Nishu', 'Patel', 'BAPS PRAMUKH SWAMI HOSPITAL', 'kur_kuriyuuu', 'nishu@gmail.com', 'yash', '07/02/1978', 'female', 'ghar Nathi', 'Gujarat', 'Road Parr', '984567', '745284926', 'Kai Khas Nahi', 'Exp 0.8 years', 'doctor/kur_kuriyuuu/1..12.png'),
(7, 'Priyal', 'Parikh', 'APPLE HOSPITAL', 'priyalparikh', 'Priyal@gmail.com', 'yash', '06/02/2001', 'female', '3 /A opp osia g mart', 'Gujarat', 'Gandhinagar', '866445', '9363564534', 'Gynaecologist', 'Exe 5 yrs', 'doctor/priyalparikh/1..13.png'),
(8, 'Yash', 'Kheni', 'APPLE HOSPITAL', 'yashkheni', 'yashkheni5849@gmail.com', 'yash', '31/01/2001', 'male', 'PUNAGAM', 'Gujarat', 'Surat', '395010', '08000892690', 'Heart Specialist', 'Exp 10 yrs', 'doctor/yashkheni/1..d1.png'),
(9, 'Dhyey', 'Bhimani', 'CIMS HOSPITAL', 'dhyeybhimani', 'dhyey@gmail.com', 'yash', '06/03/2002', 'male', 'jimu Society', 'Gujarat', 'Vapi', '23456', '948463545376', 'Dental ', 'Exe 6 yrs', 'doctor/dhyeybhimani/1..d10.jpg'),
(10, 'Yash', 'Kheni', 'CIMS HOSPITAL', 'yashkheni', 'yashkheni5849@gmail.com', 'yash', '31/01/2001', 'male', 'PUNAGAM', 'Gujarat', 'Surat', '395010', '08000892690', 'Heart Specialist', 'Exp 10 yrs', 'doctor/yashkheni/1..d1.png'),
(11, 'Heet', 'Patel', 'CIMS HOSPITAL', 'heetpatel', 'hiitpatel@gmail.com', 'yash', '14/09/2001', 'male', '2/A , Vaishnav Society, Dhandhuka', 'Guajrat', 'Dhandhuka', '382460', '8490883283', 'Skin Specialist', 'Exe 5 yrs in skin consultancy.', 'doctor/heetpatel/1..11.png'),
(12, 'Priyal', 'Parikh', 'CIMS HOSPITAL', 'priyalparikh', 'Priyal@gmail.com', 'yash', '06/02/2001', 'female', '3 /A opp osia g mart', 'Gujarat', 'Gandhinagar', '866445', '9363564534', 'Gynaecologist', 'Exe 5 yrs', 'doctor/priyalparikh/1..13.png');

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `ID` int(11) NOT NULL,
  `UNIQUE_ID` varchar(500) NOT NULL DEFAULT '-',
  `F_NAME` varchar(500) NOT NULL,
  `L_NAME` varchar(500) NOT NULL,
  `EMAIL` varchar(500) NOT NULL,
  `PASSWORD` varchar(500) NOT NULL,
  `DOB` varchar(500) NOT NULL,
  `CONTACT` varchar(500) NOT NULL,
  `HOSPITAL_NAME` varchar(500) NOT NULL,
  `H_E_CONTACT` varchar(500) NOT NULL,
  `H_STATE` varchar(500) NOT NULL,
  `H_CITY` varchar(500) NOT NULL,
  `H_DISTRICT` varchar(500) NOT NULL,
  `H_ADD_NUM` varchar(500) NOT NULL,
  `H_ADD_LOCALITY` varchar(500) NOT NULL,
  `H_ADD_LANDMARK` varchar(500) NOT NULL,
  `H_ADD_PIN` varchar(500) NOT NULL,
  `H_DES` varchar(500) NOT NULL,
  `IMAGE_PATH` varchar(500) NOT NULL,
  `STATUS` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`ID`, `UNIQUE_ID`, `F_NAME`, `L_NAME`, `EMAIL`, `PASSWORD`, `DOB`, `CONTACT`, `HOSPITAL_NAME`, `H_E_CONTACT`, `H_STATE`, `H_CITY`, `H_DISTRICT`, `H_ADD_NUM`, `H_ADD_LOCALITY`, `H_ADD_LANDMARK`, `H_ADD_PIN`, `H_DES`, `IMAGE_PATH`, `STATUS`) VALUES
(1, '1504 5126 4397 6896', 'Yash', 'Kheni', 'baps@gmail.com', 'yash', '2002-02-09', '8462846284', 'BAPS PRAMUKH SWAMI HOSPITAL', '7384728372', 'Gujarat', 'Surat', 'Adajan', 'B-21/22/23/24 Baps Hospital', 'near Tapi Bridge', 'Adajan', '395006', 'since 1998', 'hospital/baps@gmail.com/1.45903320.11.png', 1),
(2, '8656 6887 1170 6750', 'Heet', 'Patel', 'apple@gmail.com', 'yash', '2002-01-09', '8787878787', 'APPLE HOSPITAL', '898989898', 'Gujarat', 'Surat', 'Yogichowk', 'B-21/22/23/24 Baps Hospital', 'near Tapi Bridge', 'Adajan', '395006', 'since 1995', '', 1),
(3, '-', 'Dhyey', 'Bhimani', 'civil@gmail.com', 'yash', '2002-01-09', '8787878787', 'CIVIL HOSPITAL', '8787878787', 'Gujarat', 'Surat', 'kapodra', 'B-21/22/23/24 Baps Hospital', 'near Tapi Bridge', 'Adajan', '395006', 'since 1992', '', 0),
(4, '8484 5413 6853 3424', 'Meet', 'Patel', 'cims@gmail.com', 'yash', '2002-01-09', '8787878787', 'CIMS HOSPITAL', '38473487378', 'Gujarat', 'Surat', 'Sarthana', 'B-21/22/23/24 Baps Hospital', 'near Tapi Bridge', 'Adajan', '395006', 'since 1990', '', 1),
(5, '5201 1290 7990 8678', 'Priyal', 'Parikh', 'zydus@gmail.com', 'yash', '2002-01-09', '8787878787', 'ZYDUS HOSPITAL', '3846367463', 'Gujarat', 'Surat', 'Punagam', 'B-21/22/23/24 Baps Hospital', 'near Tapi Bridge', 'Adajan', '395006', 'since 19985', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `new_patient`
--

CREATE TABLE `new_patient` (
  `ID` int(11) NOT NULL,
  `UNIQUE_ID` varchar(500) NOT NULL,
  `PATIENT_NAME` varchar(500) NOT NULL,
  `HOSPITAL_NAME` varchar(500) NOT NULL,
  `STATUS` varchar(500) NOT NULL DEFAULT '0',
  `DATE` varchar(500) NOT NULL,
  `TIME` varchar(500) NOT NULL,
  `DAY` varchar(500) NOT NULL,
  `BLOOD_PRESSURE` varchar(500) NOT NULL DEFAULT '-',
  `SUGAR_LEVEL` varchar(500) NOT NULL DEFAULT '-',
  `SPO2` varchar(500) NOT NULL,
  `TEMPRETURE` varchar(500) NOT NULL,
  `BRIEF_DESCRIPTION_OF_DIESES` varchar(500) NOT NULL,
  `DR_NAME` varchar(500) NOT NULL,
  `MEDICINE` varchar(500) NOT NULL,
  `ADVICE` varchar(500) NOT NULL,
  `NEXT_APPOINMENT` varchar(500) NOT NULL DEFAULT '-',
  `PAYMENT_STATUS` varchar(500) NOT NULL DEFAULT 'PENDING',
  `PAYMENT` varchar(500) NOT NULL,
  `PATIENT_ADDED_MONEY` varchar(500) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `new_patient`
--

INSERT INTO `new_patient` (`ID`, `UNIQUE_ID`, `PATIENT_NAME`, `HOSPITAL_NAME`, `STATUS`, `DATE`, `TIME`, `DAY`, `BLOOD_PRESSURE`, `SUGAR_LEVEL`, `SPO2`, `TEMPRETURE`, `BRIEF_DESCRIPTION_OF_DIESES`, `DR_NAME`, `MEDICINE`, `ADVICE`, `NEXT_APPOINMENT`, `PAYMENT_STATUS`, `PAYMENT`, `PATIENT_ADDED_MONEY`) VALUES
(1, '1323 7194 4657 1980', 'heet  patel', 'APPLE HOSPITAL', '1', '07-02-22', '11:48:02 PM', 'Mon', '100', '100', '100', '100', 'fever', 'Dr. Yash Kheni ( Heart Specialist )', 'paracetamol , dolo 250', 'take light food few days', '', 'SUCCESS', '25000', '25000'),
(2, '6915 7658 1875 2963', 'Meet Guna', 'BAPS PRAMUKH SWAMI HOSPITAL', '1', '08-02-22', '12:01:49 AM', 'Tue', '140', '120', '99', '89', 'fever', 'Dr. Priyal Parikh ( Gynaecologist )', 'Asthakind syrp', 'take rest few days', '09/07/2021', 'SUCCESS', '35000', '35000'),
(3, '1323 7194 4657 1980', 'heet  patel', 'CIMS HOSPITAL', '0', '08-02-22', '10:45:13 AM', 'Tue', '100', '200', '200', '209', 'FEVER', 'Dr. Yash Kheni ( Heart Specialist )', '', '', '-', 'PENDING', '', '0'),
(4, '8953 9859 1549 3959', 'rishabh pant', 'BAPS PRAMUKH SWAMI HOSPITAL', '1', '23-04-22', '10:08:01 AM', 'Sat', '100', '20', '34', '45', 'nnjnjjnjnjnjnjn', 'Dr. Yash Kheni ( Heart Specialist )', 'uu', 'swdwd', '78787878', 'SUCCESS', '2022', '2022'),
(5, '1323 7194 4657 1980', 'yash kheni', 'BAPS PRAMUKH SWAMI HOSPITAL', '0', '26-04-22', '11:45:51 AM', 'Tue', '19', '8', '8', '8', '888', 'Dr. Yash Kheni ( Heart Specialist )', '', '', '-', 'PENDING', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` int(11) NOT NULL,
  `UNIQUE_ID` varchar(500) NOT NULL DEFAULT '-',
  `F_NAME` varchar(500) NOT NULL,
  `L_NAME` varchar(500) NOT NULL,
  `EMAIL` varchar(500) NOT NULL,
  `PASSWORD` varchar(500) NOT NULL,
  `DOB` varchar(500) NOT NULL,
  `CONTACT` varchar(500) NOT NULL,
  `AADHAR` varchar(500) NOT NULL,
  `BLOOD_GROUP` varchar(500) NOT NULL,
  `QUALIFICATION` varchar(500) NOT NULL,
  `ALTERNATE_CONTACT` varchar(500) NOT NULL,
  `U_STATE` varchar(500) NOT NULL,
  `U_CITY` varchar(500) NOT NULL,
  `U_DISTRICT` varchar(500) NOT NULL,
  `U_ADD_NUM` varchar(500) NOT NULL,
  `U_ADD_LOCALITY` varchar(500) NOT NULL,
  `U_ADD_LANDMARK` varchar(500) NOT NULL,
  `U_ADD_PIN` varchar(500) NOT NULL,
  `IMAGE_PATH` varchar(500) NOT NULL,
  `MONEY` varchar(500) NOT NULL,
  `STATUS` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `UNIQUE_ID`, `F_NAME`, `L_NAME`, `EMAIL`, `PASSWORD`, `DOB`, `CONTACT`, `AADHAR`, `BLOOD_GROUP`, `QUALIFICATION`, `ALTERNATE_CONTACT`, `U_STATE`, `U_CITY`, `U_DISTRICT`, `U_ADD_NUM`, `U_ADD_LOCALITY`, `U_ADD_LANDMARK`, `U_ADD_PIN`, `IMAGE_PATH`, `MONEY`, `STATUS`) VALUES
(1, '1323 7194 4657 1980', 'yash', 'kheni', 'yashkheni5849@gmail.com', 'yashk', '2001-02-09', '9867894568', '6786484845888', 'b', 'student', '7867985467', 'gujarat', 'dhadhuka', 'bhavnagar', '2/A vaishnav society', 'Dhandhuka', 'Dhandhuka', '382460', '', '5100', 1),
(2, '6915 7658 1875 2963', 'Meet', 'Guna', 'meet1534@gmail.com', 'yash', '20/02/2006', '9855555555', '134624761256', 'b+', 'Student', '9768546323', 'Gujarat', 'Surat', 'Kopadara', '2/D, Jainnagar', 'Surat', 'Surat', '4563234', 'user/meet1534@gmail.com/1.62951355.d4.jpg', '16000', 1),
(3, '-', 'Dhyey', 'Bhimani', 'dhyeybhimani001@gmail.com', 'yash', '2002-02-01', '9555555555', '364728367347', 'O', 'Student', '9784526221', 'Gujarat', 'Surat', 'Varacha', '4/D , Raj garden', 'Surat', 'Surat', '234567', '', '', 0),
(4, '7347 5672 6879 3255', 'Priyal ', 'parikh ', 'Priyal@gmail.com', 'yash', '2002-03-09', '953277777', '345634654636', 'b', 'Student', '9352342334', 'a', 'Surat', 'Puna Gam', '5/D , Green Chok', 'Surat', 'Surat', '234567', '', '', 1),
(5, '-', 'Het ', 'Patel', 'het23@gmail.com', 'yash', '2001-09-08', '9745432222', '67484365375', 'b', 'Student', '9773643334', 'Gujarat', 'Gandhinagar', 'Kugasan', '4/c, shyam city', 'Gandhinagar', 'Gandhinagar', '456784', '', '', 0),
(6, '6898 2257 1886 4049', 'hitu', 'patel', 'Hitu45@gmail.com', 'yash', '2001-08-09', '9755535446', '234576548765', 'b', 'Student', '9553545645', 'Gujarat', 'dhandhuka', 'Dhandhuka', '2/a ,jims society', 'Dhandhuka', 'Dhandhuka', '382460', '', '', 0),
(7, '6291 8597 7281 3209', 'Mayku', 'Kheni', 'mayku23@gmail.com', 'yash', '2001-08-07', '9543546236', '465738494875', 'b+', 'Student', '934356425', 'Gujarat', 'Vapi', 'valsad', '3/c, jimu society', 'Valsad', 'valsad', '345345', '', '', 1),
(8, '7494 5287 4784 6077', 'ambu', 'Patel', 'ambu@gmail.com', 'yash', '2002-07-09', '9556346562', '4823954859835', 'O+', 'Student', '966474636563', 'Gujarat', 'vapi', 'valsad', '4/b, dakhu Society', 'Valsad', 'Valsad', '548765', '', '', 1),
(9, '2156 4590 9972 1960', 'Chamu ', 'Patel', 'champu@gmail.com', 'yash', '2001-09-09', '9445633344', '247858356385687', 'B+', 'Student', '93475873452', 'Gujarat', 'Vapi', 'Valsad', '5/c , ghana city', 'Valsad', 'Valsad', '353453', '', '', 1),
(10, '5885 8957 9545 7689', 'Jheni', 'Patel', 'ghre@gmail.com', 'yash', '2002-06-09', '9523465364', '236923868923', 'B+', 'Bussiness', '9343266235', 'Gujarat', 'vapi', 'Valsad', '5/c, figure society', 'valsad', 'Valsad', '343525', '', '', 0),
(11, '7976 4420 7613 4499', 'rohan', 'patel', 'rohan@gmail.com', 'yash', '2002-06-09', '8967865678', '567867897897', 'b', 'students', '8975678789', 'gujarat', 'valsad', 'valsad', '2/d/prims society', 'valsad', 'valsad', '456556', '', '', 1),
(12, '5449 9228 3686 6369', 'rohit ', 'sharma', 'rohit11@gmail.com', 'yash', '1999-02-08', '7867895463', '456537678976', 'o+', 'cricketer', '7867584590', 'gujarat', 'rajkot', 'rajkot', '5/f/gautam society', 'rajkot', 'rajkot', '567897', '', '', 1),
(13, '-', 'virat ', 'kohli', 'virat@gmail.com', 'yash', '1998-05-04', '7856984567', '456789678976', 'b+', 'student', '7865746789', 'gujarat', 'jamnagar', 'jamnagar', '3/s/gangaram society', 'jamnagar', 'jamnagar', '360530', '', '', 0),
(14, '1691 7373 8989 6720', 'ravindra', 'jadeja', 'ravindra@gmail.com', 'yash', '1997-04-09', '7845679845', '346587685609', 'o+', 'student', '6785674567', 'gujarat', 'jamnagar', 'jamnagar', '3/s/greencity society', 'jamjodhpur', 'jamnagar', '345678', '', '', 1),
(15, '8953 9859 1549 3959', 'rishabh', 'pant', 'rishabh@gmail.com', 'yash', '1990-08-09', '7856746785', '564787658765', 'b', 'student', '6758674598', 'gujarat', 'vapi', 'valsad', '2/d/sweet farm society', 'vapi', 'vapi', '346458', '', '583', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID`,`UNIQUE_ID`,`EMAIL`),
  ADD UNIQUE KEY `EMAIL` (`EMAIL`),
  ADD UNIQUE KEY `UNIQUE_ID` (`UNIQUE_ID`,`EMAIL`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`ID`,`UNIQUE_ID`,`EMAIL`),
  ADD UNIQUE KEY `EMAIL` (`EMAIL`),
  ADD UNIQUE KEY `UNIQUE_ID` (`UNIQUE_ID`,`EMAIL`);

--
-- Indexes for table `new_patient`
--
ALTER TABLE `new_patient`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`,`UNIQUE_ID`,`EMAIL`),
  ADD UNIQUE KEY `EMAIL` (`EMAIL`),
  ADD UNIQUE KEY `UNIQUE_ID` (`UNIQUE_ID`,`EMAIL`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `hospital`
--
ALTER TABLE `hospital`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `new_patient`
--
ALTER TABLE `new_patient`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
