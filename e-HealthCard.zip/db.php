<?php
	$con = mysqli_connect("localhost","root","","6th_sem_project");
?>